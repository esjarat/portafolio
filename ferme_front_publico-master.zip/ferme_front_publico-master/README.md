# **Aplicación web pública Ferme**

*versión 2.0.0*

### **Funcionalidades implementadas**

- Login de usuarios
- Registro de usuarios
- Página de productos
- Página detalle productos (a partir de la selección del usuario)
- Carro de compras
- Perfil del usuario
- Venta de productos
- Buscador de productos
