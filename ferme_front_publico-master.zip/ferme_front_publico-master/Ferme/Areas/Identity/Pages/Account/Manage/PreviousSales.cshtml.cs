using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Ferme.Areas.Identity.Pages.Account.Manage
{
    public class PreviousSalesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}