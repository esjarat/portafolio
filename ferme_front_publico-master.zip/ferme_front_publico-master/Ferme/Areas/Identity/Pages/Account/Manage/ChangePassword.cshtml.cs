using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Ferme.IdentityProvider;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
namespace Ferme.Areas.Identity.Pages.Account.Manage
{
	public class ChangePasswordModel : PageModel
	{
		private readonly UserManager<FermeUser> _userManager;
		private readonly SignInManager<FermeUser> _signInManager;
		private readonly ILogger<ChangePasswordModel> _logger;

		public ChangePasswordModel(
			UserManager<FermeUser> userManager,
			SignInManager<FermeUser> signInManager,
			ILogger<ChangePasswordModel> logger)
		{
			_userManager = userManager;
			_signInManager = signInManager;
			_logger = logger;
		}

		[BindProperty]
		public InputModel Input { get; set; }

		[TempData]
		public string StatusMessage { get; set; }

		public class InputModel
		{
			[Required(ErrorMessage = "Debes ingresar tu contraseña actual.")]
			[DataType(DataType.Password)]
			[Display(Name = "Contraseña actual")]
			public string OldPassword { get; set; }

			[Required(ErrorMessage = "Debes ingresar una nueva contraseña.")]
			[StringLength(100, ErrorMessage = "La {0} debe tener entre {2} y {1} carácteres de longitud.", MinimumLength = 6)]
			[DataType(DataType.Password)]
			[Display(Name = "Nueva contraseña")]
			public string NewPassword { get; set; }

			[DataType(DataType.Password)]
			[Display(Name = "Confirme su nueva contraseña")]
			[Compare("NewPassword", ErrorMessage = "La nueva contraseña y la contraseña de confirmación no coinciden.")]
			public string ConfirmPassword { get; set; }
		}

		public async Task<IActionResult> OnGetAsync()
		{
			var user = await _userManager.GetUserAsync(User);
			if (user == null)
			{
					return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
			}

			var hasPassword = await _userManager.HasPasswordAsync(user);
			if (!hasPassword)
			{
					return RedirectToPage("./SetPassword");
			}

			return Page();
		}

		public async Task<IActionResult> OnPostAsync()
		{
			if (!ModelState.IsValid)
			{
					return Page();
			}

			var user = await _userManager.GetUserAsync(User);
			if (user == null)
			{
					return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
			}

			var changePasswordResult = await _userManager.ChangePasswordAsync(user, Input.OldPassword, Input.NewPassword);
			if (!changePasswordResult.Succeeded)
			{
				foreach (var error in changePasswordResult.Errors)
				{
					ModelState.AddModelError(string.Empty, error.Description);
				}
				return Page();
			}

			await _signInManager.RefreshSignInAsync(user);
			_logger.LogInformation("El usuario cambió su contraseña con éxito.");
			StatusMessage = "Su contraseña a sido cambiada.";

			return RedirectToPage();
		}
	}
}